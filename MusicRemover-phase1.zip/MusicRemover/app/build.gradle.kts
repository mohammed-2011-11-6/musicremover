plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.musicremover"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.musicremover"
        minSdk = 29
        targetSdk = 34
        versionCode = 3
        versionName = "0.3"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("org.tensorflow:tensorflow-lite:2.14.0")
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.19.2")
}

// تنزيل النماذج تلقائياً أثناء البناء
val downloadModels by tasks.registering {
    val outDir = file("src/main/assets")
    doLast {
        outDir.mkdirs()
        val hf1 = "https://huggingface.co/csukuangfj/sherpa-onnx-spleeter-2stems-fp16/resolve/main/"
        val hf2 = "https://huggingface.co/vongocanhthi/acut-spleeter-2stems-fp16/resolve/main/"
        val gh = "https://github.com/breizhn/DTLN/raw/master/pretrained_model/"
        val hf3 = "https://huggingface.co/yash-04/DTLN/resolve/main/pretrained_model/"
        val sources = mapOf(
            "model_1.tflite" to Pair(listOf(gh + "model_1.tflite", hf3 + "model_1.tflite"), 100_000L),
            "model_2.tflite" to Pair(listOf(gh + "model_2.tflite", hf3 + "model_2.tflite"), 100_000L),
            "vocals.fp16.onnx" to Pair(listOf(hf1 + "vocals.fp16.onnx", hf2 + "vocals.fp16.onnx"), 1_000_000L),
            "accompaniment.fp16.onnx" to Pair(listOf(hf1 + "accompaniment.fp16.onnx", hf2 + "accompaniment.fp16.onnx"), 1_000_000L)
        )
        for ((name, spec) in sources) {
            val urls = spec.first
            val minSize = spec.second
            val f = File(outDir, name)
            if (f.exists() && f.length() > minSize) continue
            var ok = false
            for (u in urls) {
                try {
                    val c = java.net.URL(u).openConnection()
                    c.connectTimeout = 30000
                    c.readTimeout = 120000
                    c.getInputStream().use { input ->
                        f.outputStream().use { out -> input.copyTo(out) }
                    }
                    if (f.length() > minSize) { ok = true; break }
                } catch (e: Exception) {
                    println("تعذر التنزيل من $u : ${e.message}")
                }
            }
            if (!ok) throw GradleException("لم يتم تنزيل $name من أي مصدر")
            println("تم تنزيل $name (${f.length()} بايت)")
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(downloadModels) }
