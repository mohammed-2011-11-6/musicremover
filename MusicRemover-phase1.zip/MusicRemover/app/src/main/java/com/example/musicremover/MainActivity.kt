package com.example.musicremover

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val reqProjection = 100
    private val reqPerms = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "المرحلة 3: فصل الموسيقى عن الكلام.\n" +
                    "نفّذ الخطوات بالترتيب، ثم افتح يوتيوب وشغّل فيديو فيه كلام وموسيقى."
            textSize = 16f
        })

        fun addBtn(label: String, onClick: (Button) -> Unit) {
            root.addView(Button(this).apply {
                text = label
                setOnClickListener { onClick(this) }
            })
        }

        addBtn("1) السماح بالظهور فوق التطبيقات") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        }
        addBtn("2) السماح بالميكروفون والإشعارات") {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), reqPerms)
        }
        addBtn("المحرّك: ${Config.modeNames[Config.mode(this)]} (اضغط للتغيير)") { b ->
            val i = Config.nextMode(this)
            b.text = "المحرّك: ${Config.modeNames[i]} (اضغط للتغيير)"
        }
        addBtn("${Config.chunkNames[Config.chunkIndex(this)]} (اضغط للتغيير)") { b ->
            val i = Config.nextChunk(this)
            b.text = "${Config.chunkNames[i]} (اضغط للتغيير)"
        }
        addBtn("قناة الخرج: ${OutputUsage.names[OutputUsage.index(this)]} (اضغط للتغيير)") { b ->
            val i = OutputUsage.next(this)
            b.text = "قناة الخرج: ${OutputUsage.names[i]} (اضغط للتغيير)"
        }
        addBtn("3) بدء التصفية") {
            when {
                !Settings.canDrawOverlays(this) -> toast("فعّل الخطوة 1 أولاً")
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ->
                    toast("فعّل الخطوة 2 أولاً")
                else -> {
                    val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    startActivityForResult(mpm.createScreenCaptureIntent(), reqProjection)
                }
            }
        }
        addBtn("إيقاف") {
            startService(Intent(this, CaptureService::class.java)
                .setAction(CaptureService.ACTION_STOP))
        }
        root.addView(TextView(this).apply {
            text = "\nمهم: عند ظهور نافذة المشاركة اختر «الشاشة بالكامل» وليس «تطبيق واحد».\n\n" +
                    "إن لم تسمع أي صوت: غيّر «قناة الخرج»، وارفع صوت المنبّه من إعدادات الصوت."
            textSize = 14f
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqProjection && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra(CaptureService.EXTRA_CODE, resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
            startForegroundService(i)
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
