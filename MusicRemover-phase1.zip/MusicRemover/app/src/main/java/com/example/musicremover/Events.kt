package com.example.musicremover

/** حالة مشتركة بسيطة بين خدمة إمكانية الوصول وخدمة الالتقاط. */
object Events {
    @Volatile var scrollCount: Int = 0
    @Volatile var lastScrollAt: Long = 0L
}
