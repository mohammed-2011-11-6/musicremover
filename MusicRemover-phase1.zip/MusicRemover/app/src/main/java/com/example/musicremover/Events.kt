package com.example.musicremover

/** عدّادات أحداث إمكانية الوصول (تشخيص: ما الذي يُطلقه يوتيوب عند تغيير الشورت؟) */
object Events {
    @Volatile var scrolled = 0
    @Volatile var content = 0
    @Volatile var selected = 0
    @Volatile var windowState = 0
    @Volatile var lastPkg = ""

    fun summary(): String =
        "تمرير $scrolled | محتوى $content | اختيار $selected | نافذة $windowState\nآخر تطبيق: $lastPkg"
}
