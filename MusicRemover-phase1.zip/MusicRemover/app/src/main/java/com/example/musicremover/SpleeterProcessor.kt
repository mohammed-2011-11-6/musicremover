package com.example.musicremover

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * فصل الكلام (vocals) عن الموسيقى بنموذج Spleeter 2stems (نسخة ONNX من sherpa-onnx).
 * الخوارزمية مطابقة لسكربت sherpa-onnx المرجعي:
 *  STFT: n_fft=4096, hop=1024, نافذة Hann دورية، أول 1024 سلة تردد، المقدار فقط يدخل النموذج.
 *  القناع = (v² + ε/2) / (v² + a² + ε) ويُطبَّق على الطيف المركّب الأصلي لكل قناة.
 *  إعادة البناء بالتراكب (overlap-add) مع القسمة على مجموع مربعات النافذة.
 */
class SpleeterProcessor(ctx: Context, requestedFrames: Int) {

    companion object {
        const val NFFT = 4096
        const val HOP = 1024
        const val BINS = 1024
        const val TAIL = NFFT - HOP
    }

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val vocals: OrtSession
    private val accomp: OrtSession
    private val tensorT: Int
    val frames: Int
    val needSamples: Int

    init {
        vocals = load(ctx, "vocals.fp16.onnx")
        accomp = load(ctx, "accompaniment.fp16.onnx")
        val info = inputInfo(vocals)
        require(info.type == OnnxJavaType.FLOAT) { "نوع إدخال النموذج غير مدعوم: ${info.type}" }
        val shape = info.shape
        require(shape.size == 4 && shape[1] == 2L && shape[3] == BINS.toLong()) {
            "شكل إدخال غير متوقع: ${shape.joinToString(",")}"
        }
        val modelT = shape[2].toInt()
        if (modelT > 0) {
            tensorT = modelT
            frames = min(requestedFrames, modelT)
        } else {
            tensorT = requestedFrames
            frames = requestedFrames
        }
        needSamples = frames * HOP + TAIL
    }

    private val fft = Fft(NFFT)
    private val win = FloatArray(NFFT) { (0.5 * (1.0 - cos(2.0 * PI * it / NFFT))).toFloat() }
    private val re = FloatArray(NFFT)
    private val im = FloatArray(NFFT)
    private val specRe = Array(2) { FloatArray(frames * BINS) }
    private val specIm = Array(2) { FloatArray(frames * BINS) }
    private val inBuf: FloatBuffer =
        ByteBuffer.allocateDirect(2 * tensorT * BINS * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val ola = Array(2) { FloatArray(needSamples) }
    private val wsum = FloatArray(needSamples)
    private val olaCarry = Array(2) { FloatArray(TAIL) }
    private val wCarry = FloatArray(TAIL)

    private fun load(ctx: Context, name: String): OrtSession {
        val bytes = ctx.assets.open(name).use { it.readBytes() }
        val opts = OrtSession.SessionOptions()
        opts.setIntraOpNumThreads(4)
        opts.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        return env.createSession(bytes, opts)
    }

    private fun inputInfo(s: OrtSession): TensorInfo {
        val name = s.inputNames.iterator().next()
        return s.inputInfo[name]!!.info as TensorInfo
    }

    private fun run(s: OrtSession): FloatArray {
        val name = s.inputNames.iterator().next()
        val shape = longArrayOf(1, 2, tensorT.toLong(), BINS.toLong())
        inBuf.rewind()
        val tensor = OnnxTensor.createTensor(env, inBuf, shape)
        try {
            val res = s.run(mapOf(name to tensor))
            try {
                val out = res.get(0) as OnnxTensor
                val fb = out.floatBuffer
                val arr = FloatArray(fb.remaining())
                fb.get(arr)
                require(arr.size == 2 * tensorT * BINS) { "حجم مخرجات غير متوقع: ${arr.size}" }
                return arr
            } finally {
                res.close()
            }
        } finally {
            tensor.close()
        }
    }

    /**
     * inL/inR: needSamples عينة (44.1 كيلوهرتز). يكتب frames*HOP عينة مصفّاة في outL/outR.
     * أول TAIL عينة من الإدخال هي ذيل الدفعة السابقة (أو أصفار في البداية).
     */
    fun processChunk(inL: FloatArray, inR: FloatArray, outL: FloatArray, outR: FloatArray) {
        val chans = arrayOf(inL, inR)
        for (ch in 0..1) {
            val x = chans[ch]
            for (f in 0 until frames) {
                val base = f * HOP
                for (i in 0 until NFFT) { re[i] = x[base + i] * win[i]; im[i] = 0f }
                fft.transform(re, im, false)
                val sb = f * BINS
                val ib = (ch * tensorT + f) * BINS
                for (k in 0 until BINS) {
                    val r = re[k]
                    val m = im[k]
                    specRe[ch][sb + k] = r
                    specIm[ch][sb + k] = m
                    inBuf.put(ib + k, sqrt(r * r + m * m))
                }
            }
        }

        val v = run(vocals)
        val a = run(accomp)

        for (ch in 0..1) {
            java.util.Arrays.fill(ola[ch], 0f)
            System.arraycopy(olaCarry[ch], 0, ola[ch], 0, TAIL)
        }
        java.util.Arrays.fill(wsum, 0f)
        System.arraycopy(wCarry, 0, wsum, 0, TAIL)

        for (ch in 0..1) {
            val o = ola[ch]
            for (f in 0 until frames) {
                val sb = f * BINS
                val ib = (ch * tensorT + f) * BINS
                java.util.Arrays.fill(re, 0f)
                java.util.Arrays.fill(im, 0f)
                for (k in 0 until BINS) {
                    val vv = v[ib + k]
                    val aa = a[ib + k]
                    val v2 = vv * vv
                    val a2 = aa * aa
                    val m = (v2 + 5e-11f) / (v2 + a2 + 1e-10f)
                    re[k] = specRe[ch][sb + k] * m
                    im[k] = specIm[ch][sb + k] * m
                }
                for (k in 1 until BINS) { re[NFFT - k] = re[k]; im[NFFT - k] = -im[k] }
                fft.transform(re, im, true)
                val base = f * HOP
                for (i in 0 until NFFT) o[base + i] += re[i] * win[i]
                if (ch == 0) for (i in 0 until NFFT) wsum[base + i] += win[i] * win[i]
            }
        }

        val n = frames * HOP
        for (i in 0 until n) {
            val w = max(wsum[i], 1e-3f)
            outL[i] = ola[0][i] / w
            outR[i] = ola[1][i] / w
        }
        for (ch in 0..1) System.arraycopy(ola[ch], n, olaCarry[ch], 0, TAIL)
        System.arraycopy(wsum, n, wCarry, 0, TAIL)
    }

    fun close() {
        runCatching { vocals.close() }
        runCatching { accomp.close() }
    }
}
