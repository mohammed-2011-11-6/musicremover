package com.example.musicremover

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import kotlin.math.sqrt

/**
 * المرحلة 1 (اختبار الحسم):
 *  1) خفض صوت الوسائط إلى 0 (يُكتم يوتيوب)
 *  2) التقاط صوت التطبيقات الأخرى
 *  3) عرض مستوى الصوت الملتقط فوق الشاشة لنعرف هل الالتقاط يعمل مع الكتم
 */
class CaptureService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "stop"
        private const val CHANNEL = "capture"
        private const val SAMPLE_RATE = 44100
        private const val TAG = "MusicRemover"
    }

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    private var thread: Thread? = null
    @Volatile private var running = false
    private var overlay: Overlay? = null
    private var savedVolume = -1

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY

        // يجب بدء الخدمة الأمامية قبل الحصول على MediaProjection (أندرويد 14+)
        startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)
        projection = proj

        // خفض صوت الوسائط إلى صفر
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        savedVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)

        overlay = Overlay(this).also { it.show("جاري التصفية... (اختبار)") }

        val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
            .build()
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)

        val rec = try {
            AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(minBuf * 4)
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
        } catch (e: Exception) {
            Log.e(TAG, "AudioRecord failed", e)
            overlay?.show("فشل إنشاء الالتقاط: ${e.message}")
            main.postDelayed({ stopSelf() }, 4000)
            return START_NOT_STICKY
        }
        record = rec
        running = true
        thread = Thread { captureLoop(rec) }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun captureLoop(rec: AudioRecord) {
        val buf = ShortArray(4096)
        var maxRms = 0.0
        var lastUi = 0L
        val start = SystemClock.elapsedRealtime()
        rec.startRecording()
        while (running) {
            val n = rec.read(buf, 0, buf.size)
            if (n <= 0) continue
            var sum = 0.0
            for (i in 0 until n) { val v = buf[i].toDouble(); sum += v * v }
            val rms = sqrt(sum / n)
            if (rms > maxRms) maxRms = rms

            val now = SystemClock.elapsedRealtime()
            if (now - lastUi > 300) {
                lastUi = now
                val sec = (now - start) / 1000
                val verdict = when {
                    sec < 10 -> "يجري الاختبار... شغّل فيديو فيه صوت"
                    maxRms > 100 -> "✅ الالتقاط يعمل والصوت مكتوم"
                    else -> "❌ لم يُلتقط صوت (هل الفيديو يعمل؟)"
                }
                val text = "جاري التصفية... ($sec ث)\nمستوى الصوت الملتقط: ${rms.toInt()}\n" +
                        "عدد التمريرات: ${Events.scrollCount}\n$verdict"
                main.post { overlay?.show(text) }
            }
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "التقاط الصوت", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("مزيل الموسيقى يعمل")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
    }

    override fun onDestroy() {
        running = false
        thread?.join(500)
        runCatching { record?.stop() }
        record?.release()
        projection?.stop()
        if (savedVolume >= 0) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.setStreamVolume(AudioManager.STREAM_MUSIC, savedVolume, 0)
        }
        overlay?.hide()
        super.onDestroy()
    }
}
