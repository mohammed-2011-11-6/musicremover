package com.example.musicremover

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.min

/**
 * التقاط صوت التطبيقات -> تصفية -> تشغيل على قناة مستقلة (وصوت الوسائط الأصلي مكتوم).
 * الوضع 0: Spleeter (جودة أعلى، تأخير بقدر طول المقطع + زمن المعالجة).
 * الوضع 1: DTLN (لحظي، أضعف).
 */
class CaptureService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "stop"
        private const val CHANNEL = "capture"
        private const val TAG = "MusicRemover"
        private const val DTLN_RATE = 48000
        private const val SPL_RATE = 44100
    }

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    private val threads = java.util.Collections.synchronizedList(mutableListOf<Thread>())
    @Volatile private var running = false
    private var overlay: Overlay? = null
    private var savedVolume = -1
    private var mode = Config.MODE_SPLEETER
    private var rate = SPL_RATE

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY

        startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)
        projection = proj

        mode = Config.mode(this)
        rate = if (mode == Config.MODE_SPLEETER) SPL_RATE else DTLN_RATE

        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        savedVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)

        overlay = Overlay(this).also { it.show("جاري التحضير...") }

        val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(rate)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
            .build()
        val minBuf = AudioRecord.getMinBufferSize(
            rate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)

        val rec = try {
            AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(maxOf(minBuf * 4, rate * 4 / 5))
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
        } catch (e: Exception) {
            Log.e(TAG, "AudioRecord failed", e)
            overlay?.show("فشل الالتقاط: ${e.message}")
            main.postDelayed({ stopSelf() }, 4000)
            return START_NOT_STICKY
        }
        record = rec
        running = true
        val t = Thread {
            try {
                if (mode == Config.MODE_SPLEETER) runSpleeter(rec) else runDtln(rec)
            } catch (e: Throwable) {
                Log.e(TAG, "pipeline crashed", e)
                fail("خطأ: ${e.message}")
            }
        }
        threads.add(t)
        t.start()
        return START_NOT_STICKY
    }

    private fun fail(msg: String) {
        main.post {
            overlay?.show(msg)
            main.postDelayed({ stopSelf() }, 8000)
        }
    }

    private fun createTrack(stereo: Boolean): AudioTrack {
        val mask = if (stereo) AudioFormat.CHANNEL_OUT_STEREO else AudioFormat.CHANNEL_OUT_MONO
        val minBuf = AudioTrack.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
        val bytesPerSec = rate * 2 * (if (stereo) 2 else 1)
        return AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(OutputUsage.value(this))
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build())
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(mask)
                    .build())
            .setBufferSizeInBytes(maxOf(minBuf, bytesPerSec / 5))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
    }

    private fun toShort(v: Float): Short =
        (v * 32767f).toInt().coerceIn(-32768, 32767).toShort()

    // ------------------------------------------------------------------
    //  الوضع القوي: Spleeter
    // ------------------------------------------------------------------
    private fun runSpleeter(rec: AudioRecord) {
        main.post { overlay?.show("جاري تحميل النموذج (قد يستغرق دقيقة)...") }
        val spl: SpleeterProcessor
        val out: AudioTrack
        try {
            spl = SpleeterProcessor(this, Config.chunkFrames(this))
            out = createTrack(true)
        } catch (t: Throwable) {
            Log.e(TAG, "init failed", t)
            fail("فشل التحميل: ${t.message}")
            return
        }

        val hop = SpleeterProcessor.HOP
        val tail = SpleeterProcessor.TAIL
        val frames = spl.frames
        val need = spl.needSamples
        val chunkSec = frames * hop / SPL_RATE.toFloat()
        val inQ = LinkedBlockingQueue<ShortArray>()
        val outQ = LinkedBlockingQueue<ShortArray>()
        val maxBlocks = frames * 3
        val dropped = AtomicInteger(0)
        val firstOut = AtomicLong(0L)
        val lastComputeMs = AtomicLong(0L)

        out.play()
        val startMs = SystemClock.elapsedRealtime()
        rec.startRecording()

        val capture = Thread {
            val buf = ShortArray(2048)
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                inQ.offer(buf.copyOf(n))
                while (inQ.size > maxBlocks) { inQ.poll(); dropped.incrementAndGet() }
            }
        }
        val player = Thread {
            val silence = ShortArray(1764)
            try {
                while (running) {
                    val b = outQ.poll(20, TimeUnit.MILLISECONDS)
                    if (b != null) out.write(b, 0, b.size)
                    else if (firstOut.get() != 0L) out.write(silence, 0, silence.size)
                }
            } finally {
                runCatching { out.stop() }
                out.release()
            }
        }
        threads.add(capture); threads.add(player)
        capture.start(); player.start()

        val inL = FloatArray(need)
        val inR = FloatArray(need)
        val outL = FloatArray(frames * hop)
        val outR = FloatArray(frames * hop)
        var have = tail // أصفار في البداية (حشو أمامي)
        var lastUi = 0L
        var hidden = false

        try {
            while (running) {
                val blk = inQ.poll(100, TimeUnit.MILLISECONDS)
                if (blk != null) {
                    val nf = blk.size / 2
                    var idx = 0
                    while (idx < nf && running) {
                        val take = min(nf - idx, need - have)
                        for (i in 0 until take) {
                            inL[have + i] = blk[2 * (idx + i)] / 32768f
                            inR[have + i] = blk[2 * (idx + i) + 1] / 32768f
                        }
                        have += take
                        idx += take
                        if (have == need) {
                            val t0 = SystemClock.elapsedRealtime()
                            spl.processChunk(inL, inR, outL, outR)
                            lastComputeMs.set(SystemClock.elapsedRealtime() - t0)

                            val total = frames * hop
                            var p = 0
                            while (p < total) {
                                val m = min(2205, total - p)
                                val o = ShortArray(m * 2)
                                for (i in 0 until m) {
                                    o[2 * i] = toShort(outL[p + i])
                                    o[2 * i + 1] = toShort(outR[p + i])
                                }
                                outQ.offer(o)
                                p += m
                            }
                            if (firstOut.get() == 0L) firstOut.set(SystemClock.elapsedRealtime())

                            System.arraycopy(inL, frames * hop, inL, 0, tail)
                            System.arraycopy(inR, frames * hop, inR, 0, tail)
                            have = tail
                        }
                    }
                }

                val now = SystemClock.elapsedRealtime()
                if (now - lastUi > 500) {
                    lastUi = now
                    val comp = lastComputeMs.get() / 1000f
                    val fo = firstOut.get()
                    val slow = comp > chunkSec
                    val warn = if (slow) "\n⚠️ المعالجة أبطأ من التشغيل: اختر مقطعاً أطول" else ""
                    val text: String? = when {
                        fo == 0L -> "جاري التصفية... (${(now - startMs) / 1000} ث)\n" +
                                "طول المقطع ${"%.1f".format(chunkSec)} ث" +
                                (if (comp > 0f) " | آخر معالجة ${"%.1f".format(comp)} ث" else "") + warn
                        now - fo < 10000 -> "التصفية تعمل ✅\nتأخر الصوت عن الصورة ≈ ${(fo - startMs) / 1000} ث" +
                                " | المعالجة ${"%.1f".format(comp)} ث لكل ${"%.1f".format(chunkSec)} ث" + warn
                        slow -> "⚠️ المعالجة أبطأ من التشغيل (${"%.1f".format(comp)} ث لكل ${"%.1f".format(chunkSec)} ث)\n" +
                                "اختر مقطعاً أطول (12 ثانية) أو المحرّك اللحظي"
                        else -> null
                    }
                    if (text != null) { hidden = false; main.post { overlay?.show(text) } }
                    else if (!hidden) { hidden = true; main.post { overlay?.hide() } }
                }
            }
        } finally {
            spl.close()
        }
    }

    // ------------------------------------------------------------------
    //  الوضع اللحظي: DTLN
    // ------------------------------------------------------------------
    private fun runDtln(rec: AudioRecord) {
        val dtln: DtlnProcessor
        val out: AudioTrack
        try {
            dtln = DtlnProcessor(this)
            out = createTrack(false)
        } catch (t: Throwable) {
            Log.e(TAG, "init failed", t)
            fail("فشل التحميل: ${t.message}")
            return
        }
        out.play()
        rec.startRecording()

        val inBuf = ShortArray(1920)
        val acc48 = FloatArray(8192); var n48 = 0
        val pend = FloatArray(4096); var nPend = 0
        val blockIn = FloatArray(DtlnProcessor.SHIFT)
        val blockOut = FloatArray(DtlnProcessor.SHIFT)
        val outShorts = ShortArray(DtlnProcessor.SHIFT * 3)
        var prev = 0f
        var avgMs = -1f
        var lastUi = 0L
        var hidden = false
        val start = SystemClock.elapsedRealtime()

        try {
            while (running) {
                val n = rec.read(inBuf, 0, inBuf.size)
                if (n <= 0) continue
                var i = 0
                while (i + 1 < n) {
                    acc48[n48++] = (inBuf[i].toInt() + inBuf[i + 1].toInt()) / 65536f
                    i += 2
                }
                var j = 0
                while (j + 3 <= n48) {
                    pend[nPend++] = (acc48[j] + acc48[j + 1] + acc48[j + 2]) / 3f
                    j += 3
                }
                val rem = n48 - j
                if (rem > 0) System.arraycopy(acc48, j, acc48, 0, rem)
                n48 = rem

                var p = 0
                while (nPend - p >= DtlnProcessor.SHIFT) {
                    System.arraycopy(pend, p, blockIn, 0, DtlnProcessor.SHIFT)
                    p += DtlnProcessor.SHIFT
                    val t0 = System.nanoTime()
                    dtln.process(blockIn, blockOut)
                    val ms = (System.nanoTime() - t0) / 1e6f
                    avgMs = if (avgMs < 0f) ms else avgMs * 0.98f + ms * 0.02f
                    for (k in 0 until DtlnProcessor.SHIFT) {
                        val cur = blockOut[k].coerceIn(-1f, 1f)
                        val d = cur - prev
                        outShorts[k * 3] = toShort(prev + d / 3f)
                        outShorts[k * 3 + 1] = toShort(prev + 2f * d / 3f)
                        outShorts[k * 3 + 2] = toShort(cur)
                        prev = cur
                    }
                    out.write(outShorts, 0, outShorts.size)
                }
                val rem2 = nPend - p
                if (rem2 > 0) System.arraycopy(pend, p, pend, 0, rem2)
                nPend = rem2

                val now = SystemClock.elapsedRealtime()
                if (now - lastUi > 400) {
                    lastUi = now
                    val sec = (now - start) / 1000
                    if (sec < 20) {
                        val text = "المحرّك اللحظي... ($sec ث)\nزمن المعالجة: ${"%.1f".format(avgMs)} مللي (الحد 8)"
                        main.post { overlay?.show(text) }
                    } else if (!hidden) {
                        hidden = true
                        main.post { overlay?.hide() }
                    }
                }
            }
        } finally {
            runCatching { out.stop() }
            out.release()
            dtln.close()
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "تصفية الصوت", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("مزيل الموسيقى يعمل")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
    }

    override fun onDestroy() {
        running = false
        val list = synchronized(threads) { threads.toList() }
        for (t in list) runCatching { t.join(1500) }
        runCatching { record?.stop() }
        record?.release()
        projection?.stop()
        if (savedVolume >= 0) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.setStreamVolume(AudioManager.STREAM_MUSIC, savedVolume, 0)
        }
        overlay?.hide()
        super.onDestroy()
    }
}
