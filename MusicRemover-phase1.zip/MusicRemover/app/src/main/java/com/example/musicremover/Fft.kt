package com.example.musicremover

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** FFT مركّب بقاعدة 2 (الحجم n قوة للعدد 2). المعكوس يقسم على n. */
class Fft(private val n: Int) {
    private val cosT = FloatArray(n / 2) { cos(2.0 * PI * it / n).toFloat() }
    private val sinT = FloatArray(n / 2) { sin(2.0 * PI * it / n).toFloat() }
    private val rev = IntArray(n).also { r ->
        val bits = Integer.numberOfTrailingZeros(n)
        for (i in 0 until n) r[i] = Integer.reverse(i) ushr (32 - bits)
    }

    fun transform(a: FloatArray, b: FloatArray, inverse: Boolean) {
        for (i in 0 until n) {
            val j = rev[i]
            if (j > i) {
                val t = a[i]; a[i] = a[j]; a[j] = t
                val u = b[i]; b[i] = b[j]; b[j] = u
            }
        }
        var len = 2
        while (len <= n) {
            val half = len / 2
            val step = n / len
            var i = 0
            while (i < n) {
                for (k in 0 until half) {
                    val wr = cosT[k * step]
                    val wi = if (inverse) sinT[k * step] else -sinT[k * step]
                    val x = i + k
                    val y = x + half
                    val tr = a[y] * wr - b[y] * wi
                    val ti = a[y] * wi + b[y] * wr
                    a[y] = a[x] - tr; b[y] = b[x] - ti
                    a[x] += tr; b[x] += ti
                }
                i += len
            }
            len *= 2
        }
        if (inverse) for (i in 0 until n) { a[i] /= n; b[i] /= n }
    }
}
