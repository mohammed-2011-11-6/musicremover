package com.example.musicremover

import android.content.Context

/** إعدادات يغيّرها المستخدم من الشاشة الرئيسية (تُحفظ على الهاتف). */
object Config {
    const val MODE_SPLEETER = 0
    const val MODE_DTLN = 1

    val modeNames = arrayOf("قوي (Spleeter) مع تأخير", "لحظي (DTLN) أضعف")
    private val frameOptions = intArrayOf(128, 256, 512)
    val chunkNames = arrayOf("مقطع 3 ثوانٍ", "مقطع 6 ثوانٍ", "مقطع 12 ثانية")

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun mode(ctx: Context): Int = prefs(ctx).getInt("mode", MODE_SPLEETER).coerceIn(0, 1)
    fun nextMode(ctx: Context): Int {
        val i = (mode(ctx) + 1) % 2
        prefs(ctx).edit().putInt("mode", i).apply()
        return i
    }

    fun chunkIndex(ctx: Context): Int = prefs(ctx).getInt("chunk", 2).coerceIn(0, 2)
    fun chunkFrames(ctx: Context): Int = frameOptions[chunkIndex(ctx)]
    fun nextChunk(ctx: Context): Int {
        val i = (chunkIndex(ctx) + 1) % 3
        prefs(ctx).edit().putInt("chunk", i).apply()
        return i
    }
}
