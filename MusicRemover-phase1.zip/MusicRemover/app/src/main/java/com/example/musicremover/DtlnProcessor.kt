package com.example.musicremover

import android.content.Context
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * معالجة بنموذج DTLN (16 كيلوهرتز، كتلة 512، إزاحة 128 = 8 مللي ثانية).
 * النموذج مصمم لإزالة الضجيج الخلفي، والموسيقى إحدى أنواعه، فيُبقي الكلام ويخفض الباقي.
 */
class DtlnProcessor(ctx: Context) {

    companion object {
        const val BLOCK = 512
        const val SHIFT = 128
        const val BINS = BLOCK / 2 + 1
    }

    private class Stage(ctx: Context, assetName: String) {
        val interp: Interpreter
        val dataInBuf: ByteBuffer
        val dataOutBuf: ByteBuffer
        private val stateInBuf: ByteBuffer
        private val stateOutBuf: ByteBuffer
        private val dataIn: Int
        private val stateIn: Int
        private val dataOut: Int
        private val stateOut: Int

        init {
            val bytes = ctx.assets.open(assetName).use { it.readBytes() }
            val model = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
            model.put(bytes)
            model.rewind()
            interp = Interpreter(model, Interpreter.Options().setNumThreads(2))

            var di = -1; var si = -1; var dout = -1; var sout = -1
            for (i in 0 until interp.inputTensorCount) {
                if (interp.getInputTensor(i).shape().size == 4) si = i else di = i
            }
            for (i in 0 until interp.outputTensorCount) {
                if (interp.getOutputTensor(i).shape().size == 4) sout = i else dout = i
            }
            check(di >= 0 && si >= 0 && dout >= 0 && sout >= 0) { "شكل النموذج غير متوقع ($assetName)" }
            dataIn = di; stateIn = si; dataOut = dout; stateOut = sout

            fun buf(n: Int) = ByteBuffer.allocateDirect(n).order(ByteOrder.nativeOrder())
            dataInBuf = buf(interp.getInputTensor(di).numBytes())
            stateInBuf = buf(interp.getInputTensor(si).numBytes())
            dataOutBuf = buf(interp.getOutputTensor(dout).numBytes())
            stateOutBuf = buf(interp.getOutputTensor(sout).numBytes())
        }

        fun run() {
            val inputs = arrayOfNulls<Any>(interp.inputTensorCount)
            inputs[dataIn] = dataInBuf
            inputs[stateIn] = stateInBuf
            val outputs = HashMap<Int, Any>()
            outputs[dataOut] = dataOutBuf
            outputs[stateOut] = stateOutBuf
            dataInBuf.rewind(); stateInBuf.rewind()
            dataOutBuf.rewind(); stateOutBuf.rewind()
            interp.runForMultipleInputsOutputs(inputs, outputs)
            // نمرّر الحالة إلى الكتلة التالية
            stateOutBuf.rewind(); stateInBuf.rewind()
            stateInBuf.put(stateOutBuf)
            stateInBuf.rewind()
            dataOutBuf.rewind()
        }

        fun close() = interp.close()
    }

    private val stage1 = Stage(ctx, "model_1.tflite")
    private val stage2 = Stage(ctx, "model_2.tflite")

    private val inBuf = FloatArray(BLOCK)
    private val outBuf = FloatArray(BLOCK)
    private val re = FloatArray(BLOCK)
    private val im = FloatArray(BLOCK)
    private val er = FloatArray(BLOCK)
    private val ei = FloatArray(BLOCK)
    private val mag = FloatArray(BINS)
    private val mask = FloatArray(BINS)
    private val block = FloatArray(BLOCK)
    private val outBlock = FloatArray(BLOCK)

    private val cosT = FloatArray(BLOCK / 2) { cos(2.0 * PI * it / BLOCK).toFloat() }
    private val sinT = FloatArray(BLOCK / 2) { sin(2.0 * PI * it / BLOCK).toFloat() }
    private val rev = IntArray(BLOCK).also { r ->
        val bits = Integer.numberOfTrailingZeros(BLOCK)
        for (i in 0 until BLOCK) r[i] = Integer.reverse(i) ushr (32 - bits)
    }

    private fun fft(a: FloatArray, b: FloatArray, inverse: Boolean) {
        for (i in 0 until BLOCK) {
            val j = rev[i]
            if (j > i) {
                val t = a[i]; a[i] = a[j]; a[j] = t
                val u = b[i]; b[i] = b[j]; b[j] = u
            }
        }
        var len = 2
        while (len <= BLOCK) {
            val half = len / 2
            val step = BLOCK / len
            var i = 0
            while (i < BLOCK) {
                for (k in 0 until half) {
                    val wr = cosT[k * step]
                    val wi = if (inverse) sinT[k * step] else -sinT[k * step]
                    val x = i + k
                    val y = x + half
                    val tr = a[y] * wr - b[y] * wi
                    val ti = a[y] * wi + b[y] * wr
                    a[y] = a[x] - tr; b[y] = b[x] - ti
                    a[x] += tr; b[x] += ti
                }
                i += len
            }
            len *= 2
        }
        if (inverse) {
            val scale = 1f / BLOCK
            for (i in 0 until BLOCK) { a[i] = a[i] * scale; b[i] = b[i] * scale }
        }
    }

    /** يستقبل 128 عينة (16 كيلوهرتز) ويكتب 128 عينة مصفّاة. */
    fun process(input: FloatArray, output: FloatArray) {
        System.arraycopy(inBuf, SHIFT, inBuf, 0, BLOCK - SHIFT)
        System.arraycopy(input, 0, inBuf, BLOCK - SHIFT, SHIFT)

        for (i in 0 until BLOCK) { re[i] = inBuf[i]; im[i] = 0f }
        fft(re, im, false)
        for (k in 0 until BINS) mag[k] = sqrt(re[k] * re[k] + im[k] * im[k])

        stage1.dataInBuf.rewind()
        stage1.dataInBuf.asFloatBuffer().put(mag)
        stage1.run()
        stage1.dataOutBuf.asFloatBuffer().get(mask)

        for (k in 0 until BINS) { er[k] = re[k] * mask[k]; ei[k] = im[k] * mask[k] }
        for (k in BINS until BLOCK) { er[k] = er[BLOCK - k]; ei[k] = -ei[BLOCK - k] }
        fft(er, ei, true)
        System.arraycopy(er, 0, block, 0, BLOCK)

        stage2.dataInBuf.rewind()
        stage2.dataInBuf.asFloatBuffer().put(block)
        stage2.run()
        stage2.dataOutBuf.asFloatBuffer().get(outBlock)

        System.arraycopy(outBuf, SHIFT, outBuf, 0, BLOCK - SHIFT)
        for (i in BLOCK - SHIFT until BLOCK) outBuf[i] = 0f
        for (i in 0 until BLOCK) outBuf[i] += outBlock[i]
        System.arraycopy(outBuf, 0, output, 0, SHIFT)
    }

    fun close() {
        stage1.close()
        stage2.close()
    }
}
