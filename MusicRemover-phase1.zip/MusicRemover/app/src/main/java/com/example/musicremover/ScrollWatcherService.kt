package com.example.musicremover

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class ScrollWatcherService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return // تجاهل أحداث رسالتنا العائمة
        Events.lastPkg = pkg
        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> Events.scrolled++
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> Events.content++
            AccessibilityEvent.TYPE_VIEW_SELECTED -> Events.selected++
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> Events.windowState++
        }
    }

    override fun onInterrupt() {}
}
