package com.example.musicremover

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityEvent

/**
 * المرحلة 1: فقط نعدّ أحداث التمرير لنعرف متى ينتقل المستخدم لفيديو جديد.
 * في المرحلة 3 سنستخدمها لإعادة تشغيل التصفية عند كل فيديو.
 */
class ScrollWatcherService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            Events.scrollCount++
            Events.lastScrollAt = SystemClock.elapsedRealtime()
            Log.d("MusicRemover", "scroll in ${event.packageName}")
        }
    }

    override fun onInterrupt() {}
}
