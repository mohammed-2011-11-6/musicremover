package com.example.musicremover

import android.content.Context
import android.media.AudioAttributes

/**
 * قناة تشغيل الصوت المصفّى. نحتاج قناة لا يكتمها خفض صوت الوسائط إلى صفر
 * ولا يلتقطها التطبيق نفسه. أي القنوات تعمل أفضل يختلف بين الهواتف، لذلك نتيح التبديل.
 */
object OutputUsage {
    private val usages = intArrayOf(
        AudioAttributes.USAGE_ALARM,
        AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY,
        AudioAttributes.USAGE_VOICE_COMMUNICATION
    )
    val names = arrayOf("المنبّه", "إمكانية الوصول", "مكالمة صوتية")

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun index(ctx: Context): Int = prefs(ctx).getInt("usage", 0).coerceIn(0, usages.size - 1)
    fun value(ctx: Context): Int = usages[index(ctx)]
    fun next(ctx: Context): Int {
        val i = (index(ctx) + 1) % usages.size
        prefs(ctx).edit().putInt("usage", i).apply()
        return i
    }
}
